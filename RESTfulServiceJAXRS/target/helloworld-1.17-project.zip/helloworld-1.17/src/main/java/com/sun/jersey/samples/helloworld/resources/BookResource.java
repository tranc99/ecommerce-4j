package com.sun.jersey.samples.helloworld.resources;

import javax.ws.rs.Path;

@Path(value = "")
public class BookResource {

	
}
